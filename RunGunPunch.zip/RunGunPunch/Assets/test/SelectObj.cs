﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using nn.hid;
using UnityEngine.UI;
public enum InputSelect
{
    AnalogStick,
    JoyConStance,
    Acceleration,
}
public class SelectObj : MonoBehaviour
{
    [SerializeField]
    Text txt;
    [SerializeField]
    Text txt2;
    [SerializeField]
    List<GameObject> TargetObj = new List<GameObject>();
    [SerializeField]
    JoyConControl GetInput;
    List<Material> objmt = new List<Material>();
    [SerializeField]
    List<GameObject> Setobj = new List<GameObject>();

    InputSelect InputSelect = InputSelect.AnalogStick;
    void Start()
    {
        txt2.text = "";
        Setobj.Add(TargetObj[0]);
        Setobj.Add(TargetObj[0]);
        //StartCoroutine(SelfUpdate());
    }
    void Update()
    {
        txt.text = "Input" + InputSelect;
        if (GetInput.ButtonGet(NpadButton.ZL) && GetInput.ButtonGet(NpadButton.ZR))
        {
            switch (InputSelect)
            {
                case InputSelect.AnalogStick:
                    InputSelect = InputSelect.JoyConStance;
                    break;
                case InputSelect.JoyConStance:
                    InputSelect = InputSelect.Acceleration;
                    break;
                case InputSelect.Acceleration:
                    InputSelect = InputSelect.AnalogStick;
                    break;
            }
        }
        for (int i = 0; i <= 1; i++)
            Set(i);
    }

    void Set(int i)
    {
        float AnalogStick = 0;
        float JoyConStance = 0;
        switch (InputSelect)
        {
            case InputSelect.AnalogStick:
                if (i == 0)
                    AnalogStick = GetInput.AnalogStickGet(Hand.Left).x;
                else if (i == 1)
                    AnalogStick = GetInput.AnalogStickGet(Hand.Right).x;
                break;
            case InputSelect.JoyConStance:
                if (i == 0)
                    JoyConStance = GetInput.JoyConStanceGet(Hand.Left).y;
                if (JoyConStance >= 180) JoyConStance -= 360;
                else if (i == 1)
                    JoyConStance = GetInput.JoyConStanceGet(Hand.Right).y;
                if (JoyConStance >= 180) JoyConStance -= 360;
                break;
            case InputSelect.Acceleration:
                AccelerationSet(i);
                break;
        }
        if (InputSelect != InputSelect.Acceleration)
        {
            int x = 0;
            if (i == 1) x += 3;
            if (AnalogStick >= 0.7f || JoyConStance >= 60)
            { Mark(0 + x); Clear(2 + x); Clear(1 + x); }
            else if (AnalogStick <= -0.7f || JoyConStance <= -60)
            { Mark(2 + x); Clear(0 + x); Clear(1 + x); }
            else
            { Mark(1 + x); Clear(2 + x); Clear(0 + x); }
        }
    }


    void AccelerationSet(int i)
    {
        const float l_controlValue = 6;

        float JoyConStance = 0;
        if (i == 0)
            JoyConStance = GetInput.JoyConStanceGet(Hand.Left).y;
        else if (i == 1)
            JoyConStance = GetInput.JoyConStanceGet(Hand.Right).y;

        if (JoyConStance >= 180) JoyConStance -= 360;

        Vector3 asd = Vector3.zero;
        if (i == 0)
            asd = GetInput.JoyConStanceGet(Hand.Left);
        else if (i == 1)
            asd = GetInput.JoyConStanceGet(Hand.Right);


        Vector3 Acceleration = Vector3.zero;
        if (i == 0)
            Acceleration = GetInput.AccelerationGet(Hand.Left);
        if (i == 1)
            Acceleration = GetInput.AccelerationGet(Hand.Right);

        int x = 0;
        if (i == 1) x += 3;
        if (Acceleration.z >= l_controlValue)
        { Dest(x + 2, Acceleration); }
        else if (Acceleration.z <= -l_controlValue)
        { Dest(x + 0, Acceleration); }
        else if ((Mathf.Abs(JoyConStance) <= 60) && Mathf.Abs(Acceleration.y) >= 4)
        { Dest(x + 1, Acceleration); }
        Reset();
    }

    void Clear(int i)
    {
        TargetObj[i].GetComponent<Renderer>().material.color = Color.white;
    }
    void Mark(int i)
    {
        TargetObj[i].GetComponent<Renderer>().material.color = Color.yellow;

        if (i <= 2)
            Setobj[0] = TargetObj[i];
        else
            Setobj[1] = TargetObj[i];
    }

    void Dest(int i, Vector3 Acceleration)
    {
        Vector3 a = new Vector3(
            (Mathf.Round(Acceleration.x * 100)) / 100,
            (Mathf.Round(Acceleration.y * 100)) / 100,
            (Mathf.Round(Acceleration.z * 100)) / 100);

        TargetObj[i].SetActive(false);
        txt2.text += "TargetObj[" + i + "]:x" + a.x + "y" + a.y + "z" + a.z + "\n";
    }
    void Reset()
    {
        if (GetInput.ButtonGet(NpadButton.Plus) || GetInput.ButtonGet(NpadButton.Minus))
        {
            txt2.text = "";
            for (int i = 0; i < 6; i++)
            {
                TargetObj[i].SetActive(true);
            }
        }
    }
}
