﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using nn.hid;

public class Shake : MonoBehaviour
{
    [SerializeField]
    private Text text;

    private NpadState npadState = new NpadState();
    private NpadStyle npadStyle = NpadStyle.Invalid;
    private SixAxisSensorHandle[] handle = new SixAxisSensorHandle[2];
    private SixAxisSensorState state = new SixAxisSensorState();

    int handleCount = 0;
    private NpadId npadId;

    void Start()
    {

    }


    void Update()
    {
        NpadId npadId = NpadId.Handheld;
        NpadStyle npadStyle = NpadStyle.None;

        npadStyle = Npad.GetStyleSet(npadId);

        if (npadStyle != NpadStyle.Handheld)
        {
            npadId = NpadId.No1;
            npadStyle = Npad.GetStyleSet(npadId);
        }
        if (UpdatePadState())
            text.text = "とった";
        else
            text.text = "だめ";

        if (UpdatePadState())
        {

            for (int i = 0; i < handleCount; i++)
            {
                SixAxisSensor.GetState(ref state, handle[i]);
                int x = Mathf.FloorToInt(state.acceleration.x);
                int y = Mathf.FloorToInt(state.acceleration.y);
                int z = Mathf.FloorToInt(state.acceleration.z);
                text.text = "x" + x + "\n y" + y + "\n z" + z.ToString();

            }

        }
    }

    bool ShakeCheck()
    {

        //for (int i = 0; i < handleCount; i++)
        //{
        //    npadStyle = Npad.GetStyleSet(NpadId.Handheld);
        //    Npad.GetState(ref npadState, NpadId.Handheld, npadStyle);
        //    //SixAxisSensor.GetState(ref state, GetSixAxisSensor(NpadId.Handheld,));
        //    SixAxisSensor.GetState(ref state, handle[i]);

        //    Vector3 a = new Vector3(state.acceleration.x, state.acceleration.y, state.acceleration.z);
        //    Debug.Log(a);
        //}

        //return true;

        return false;
    }

    private void GetSixAxisSensor(NpadId id, NpadStyle style)
    {
        for (int i = 0; i < handleCount; i++)
        {
            SixAxisSensor.Stop(handle[i]);
        }

        handleCount = SixAxisSensor.GetHandles(handle, 2, id, style);

        for (int i = 0; i < handleCount; i++)
        {
            SixAxisSensor.Start(handle[i]);
        }
    }

    private bool UpdatePadState()
    {
        NpadStyle handheldStyle = Npad.GetStyleSet(NpadId.Handheld);
        NpadState handheldState = new NpadState();
        if (handheldStyle != NpadStyle.None)
        {
            Npad.GetState(ref handheldState, NpadId.Handheld, handheldStyle);
            if (handheldState.buttons != NpadButton.None)
            {
                if ((npadId != NpadId.Handheld) || (npadStyle != handheldStyle))
                {
                    this.GetSixAxisSensor(NpadId.Handheld, handheldStyle);
                }
                npadId = NpadId.Handheld;
                npadStyle = handheldStyle;
                npadState = handheldState;
                return true;
            }
        }

        NpadStyle no1Style = Npad.GetStyleSet(NpadId.No1);
        NpadState no1State = new NpadState();
        if (no1Style != NpadStyle.None)
        {
            Npad.GetState(ref no1State, NpadId.No1, no1Style);
            if (no1State.buttons != NpadButton.None)
            {
                if ((npadId != NpadId.No1) || (npadStyle != no1Style))
                {
                    this.GetSixAxisSensor(NpadId.No1, no1Style);
                }
                npadId = NpadId.No1;
                npadStyle = no1Style;
                npadState = no1State;
                return true;
            }
        }

        if ((npadId == NpadId.Handheld) && (handheldStyle != NpadStyle.None))
        {
            npadId = NpadId.Handheld;
            npadStyle = handheldStyle;
            npadState = handheldState;
        }
        else if ((npadId == NpadId.No1) && (no1Style != NpadStyle.None))
        {
            npadId = NpadId.No1;
            npadStyle = no1Style;
            npadState = no1State;
        }
        else
        {
            npadId = NpadId.Invalid;
            npadStyle = NpadStyle.Invalid;
            npadState.Clear();
            return false;
        }
        return true;
    }

}
